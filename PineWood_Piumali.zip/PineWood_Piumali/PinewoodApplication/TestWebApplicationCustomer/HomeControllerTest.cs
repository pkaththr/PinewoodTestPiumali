﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using AutoFixture;
using Castle.Core.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using WebApplicationCustomer.Controllers;
using WebApplicationCustomer.Models;
using WebApplicationCustomer.Service;

namespace TestWebApplicationCustomer
{
    [TestFixture]
    public class HomeControllerTest
    {
        private readonly IFixture fixture;
        private Mock<IDataService> mockService;
        private HomeController cusController;
        private Mock<HttpContext> _httpContextMock;
        private Mock<ClaimsPrincipal> _claimsPrincipalMock;
        private Mock<IIdentity> _identityMock;
        private ILogger<HomeController> logger;

        public HomeControllerTest() { }
        public HomeControllerTest(ILogger<HomeController> logger)
        {
            this.fixture = new Fixture();         
            this.logger = logger;
            this.cusController = new HomeController(logger, mockService.Object);
        }      

        [SetUp]
        public void TestSetup()
        {
            mockService = new Mock<IDataService>();
            _httpContextMock = new Mock<HttpContext>();
            _claimsPrincipalMock = new Mock<ClaimsPrincipal>();
            _identityMock = new Mock<IIdentity>();
            _httpContextMock.Setup(x => x.User).Returns(_claimsPrincipalMock.Object);
            _claimsPrincipalMock.Setup(x => x.Identity).Returns(_identityMock.Object);
        }

        [Test]
        public void GetCustomerWhenDataFound()
        {
            //Arrange
            Guid guid = Guid.NewGuid();
            CustomerModel customermodel = new CustomerModel();
            customermodel.CustomerId = guid;
            customermodel.CustomerFirstname = "Test";
            customermodel.CustomerLastname = "Test";
            customermodel.Email = "test@gmail.com";
            customermodel.ContactNumber = "06654534234";
            customermodel.HouseNumber = "12";
            customermodel.Street = "Test street";
            customermodel.Town = "Test Town";
            customermodel.Postcode = "LE2 2QW";

            string cid = guid.ToString();

            mockService.Setup(x => x.GetCustomerById(cid)).ReturnsAsync(customermodel).Verifiable();
            _identityMock.Setup(id => id.IsAuthenticated).Returns(true);
            this.cusController = new HomeController(logger, mockService.Object);
            var controllerContext = new ControllerContext();
            controllerContext.HttpContext = _httpContextMock.Object;
            this.cusController.ControllerContext.HttpContext = controllerContext.HttpContext;

            //Act
            var cus = cusController.ViewCustomerByCustomerId(cid).ExecuteResult;
            var result = cus.Target as ViewResult;
            var model = result.Model as CustomerModel;

            //Assert
            Assert.IsNotNull(cus);
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Model);
            Assert.AreEqual(customermodel.CustomerFirstname, model.CustomerFirstname);
        }

        [Test]
        public void GetCustomerWhenDataNotFound()
        {
            //Arrange
            Guid guid = Guid.NewGuid();
            CustomerModel? customermodel = null;         
            string cid = guid.ToString();

            mockService.Setup(x => x.GetCustomerById(cid)).ReturnsAsync(customermodel).Verifiable();
            _identityMock.Setup(id => id.IsAuthenticated).Returns(true);
            this.cusController = new HomeController(logger, mockService.Object);
            var controllerContext = new ControllerContext();
            controllerContext.HttpContext = _httpContextMock.Object;
            this.cusController.ControllerContext.HttpContext = controllerContext.HttpContext;

            //Act
            var cus = cusController.ViewCustomerByCustomerId(cid).ExecuteResult;
            var result = cus.Target as ViewResult;

            //Assert
            Assert.IsNotNull(cus);
            Assert.IsNull(result.Model);
        }

        [OneTimeTearDown]
        [TearDown]
        public void TearDown() 
        {
            this.cusController.Dispose();
        }
    }
}
