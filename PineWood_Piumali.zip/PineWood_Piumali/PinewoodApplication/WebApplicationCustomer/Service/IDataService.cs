﻿using WebApplicationCustomer.Models;

namespace WebApplicationCustomer.Service
{
    public interface IDataService
    {
        public Task<HttpResponseMessage> AddCustomer(CustomerModel customer);

        public Task<HttpResponseMessage> DeleteCustomer(string customerId);

        public Task<HttpResponseMessage> UpdateCustomer(CustomerModel customer);

        public Task<IEnumerable<CustomerModel>?> GetCustomersByNamesAsync(string? customerName = null);

        public Task<IEnumerable<CustomerModel>?> GetCustomers();

        public Task<CustomerModel?> GetCustomerById(string customerId);
    }
}
