﻿using Newtonsoft.Json;
using System.Text;
using WebApplicationCustomer.Models;

namespace WebApplicationCustomer.Service
{
    public class DataService : IDataService
    {
        readonly string BaseUrl = "https://localhost:7114/api";
        private readonly HttpClient client;
        public DataService()
        {
            client = new HttpClient(); ;
            client.BaseAddress = new Uri(BaseUrl);
        }

        public Task<HttpResponseMessage> AddCustomer(CustomerModel customer)
        {
            // Serialize the customer object to JSON
            var json = JsonConvert.SerializeObject(customer);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var res = client.PostAsync(client.BaseAddress + "/Customer/AddCustomer", content);
            return res;
        }

        public Task<HttpResponseMessage> DeleteCustomer(string customerId)
        {
            var res = client.DeleteAsync(client.BaseAddress + "/Customer/DeleteCustomer?customerId=" + customerId);
            return res;
        }

        public Task<HttpResponseMessage> UpdateCustomer(CustomerModel customer)
        {
            var json = JsonConvert.SerializeObject(customer);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var res = client.PutAsync(client.BaseAddress + "/Customer/UpdateCustomer", content);
            return res;
        }

        public async Task<IEnumerable<CustomerModel>?> GetCustomersByNamesAsync(string? customerName = null)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Customer/GetCustomersByNames?customerName="+ customerName).Result;
            IEnumerable<CustomerModel>? customerModel = null;
            if (response.IsSuccessStatusCode && response != null)
            {
                string responseData = await response.Content.ReadAsStringAsync();
                customerModel = JsonConvert.DeserializeObject<IEnumerable<CustomerModel>>(responseData);
                return customerModel;
            }
            else
            {
                return null;
            }
        }

        public async Task<IEnumerable<CustomerModel>?> GetCustomers()
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Customer/GetCustomers").Result;
            IEnumerable<CustomerModel>? customerModel = null;
            if (response.IsSuccessStatusCode && response != null)
            {
                string responseData = await response.Content.ReadAsStringAsync();
                customerModel = JsonConvert.DeserializeObject<IEnumerable<CustomerModel>>(responseData);
                return customerModel;
            }
            else
            {
                return null;
            }
        }

        public async Task<CustomerModel?> GetCustomerById(string customerId)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Customer/GetCustomerById?customerId="+ customerId).Result;
            if (response.IsSuccessStatusCode && response != null)
            {
                string responseData = await response.Content.ReadAsStringAsync();
                var customerModel = JsonConvert.DeserializeObject<CustomerModel>(responseData);
                return customerModel;
            }
            else
            {
                return null;
            }
        }
    }
}
