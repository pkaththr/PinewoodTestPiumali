using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplicationCustomer.Models;
using WebApplicationCustomer.Service;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;

namespace WebApplicationCustomer.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IDataService _dataService;

        public HomeController(ILogger<HomeController> logger, IDataService dataService)
        {
            _logger = logger;
            _dataService = dataService;
        }

        [AllowAnonymous]
        public IActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public async Task<IActionResult> Login(User user)
        {
            if (ModelState.IsValid || user != null)
            {
                //Hard coded username and password
                if (user.UserName.Equals("Admin", StringComparison.InvariantCultureIgnoreCase) && user.Password.Equals("password"))
                {
                    var claims = new List<Claim>
                    {
                      new Claim(ClaimTypes.Name, user.UserName)
                    };

                    var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                    var authProperties = new AuthenticationProperties
                    {
                        IsPersistent = false,                    
                        AllowRefresh = true
                    };

                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(claimsIdentity),authProperties);
                    return RedirectToAction("ViewCustomers", "Home");
                }
                else
                {
                    ModelState.AddModelError("Password", "Incorrect password");
                    return View("Index");
                }
            }
            return View("Index");
        }

        [HttpPost]
        public ActionResult Logout()
        {
            HttpContext.SignOutAsync();
            return RedirectToAction("Index");                     
        }

        public ActionResult SearchCustomers(string? customerName = null)
        {
            if (HttpContext.User.Identity.IsAuthenticated)
            {
                if (customerName is not null)
                {
                    List<CustomerModel> modelList = new List<CustomerModel>();
                    modelList = _dataService.GetCustomersByNamesAsync(customerName).Result.ToList();
                    return View("ViewCustomers", modelList);

                }
                return RedirectToAction("ViewCustomers");
            }

            return RedirectToAction("Index");
        }

        public ActionResult ViewCustomers()
        {
            if (HttpContext.User.Identity.IsAuthenticated)
            {
                
                List<CustomerModel> modelList = new List<CustomerModel>();
               
                modelList = _dataService.GetCustomers().Result.ToList();
                if (modelList != null)
                {
                    return View(modelList);
                }             
            }
            return RedirectToAction("Index");
        }

        //Get Customer details by Customer Id
        public ActionResult ViewCustomerByCustomerId(string customerId)
        {
            if (User.Identity.IsAuthenticated)
            {
                CustomerModel? model = new CustomerModel();
                model = _dataService.GetCustomerById(customerId).Result;
                if (model is not null)
                {
                    model.IsUpdated = false;
                }              
                return View(model);
            }

            return RedirectToAction("Index");
        }

        //Update customer
        public ActionResult EditCustomer(CustomerModel customer)
        {   
            if (HttpContext.User.Identity.IsAuthenticated)
            {
                ValidateCustomer(customer);

                if (ModelState.IsValid)
                {
                    var res = _dataService.UpdateCustomer(customer).Result;
                    if (res != null && res.IsSuccessStatusCode)
                    {
                        customer.IsUpdated = true;
                        return View("ViewCustomerByCustomerId", customer);
                    }
                }
                else 
                {
                    return View("ViewCustomerByCustomerId", customer);
                }
            }
            return RedirectToAction("Index");
        }

        //Delete customer
        public ActionResult DeleteCustomer(string customerId)
        {
            if (HttpContext.User.Identity.IsAuthenticated)
            {
                var res = _dataService.DeleteCustomer(customerId).Result;
                if (res != null && res.IsSuccessStatusCode)
                {
                    return RedirectToAction("ViewCustomers");
                }               
            }
            return RedirectToAction("Index");
        }
      
        public ActionResult AddCustomer()
        {
            if (HttpContext.User.Identity.IsAuthenticated)
            {
                return View();
            }
            return RedirectToAction("Index");
        }

        //Add new customer
        public ActionResult AddNewCustomer(CustomerModel customer)
        {
            if (HttpContext.User.Identity.IsAuthenticated)
            {
                ValidateCustomer(customer);
                
                if (ModelState.IsValid)
                {
                    var res = _dataService.AddCustomer(customer).Result;
                    if (res != null && res.IsSuccessStatusCode)
                    {
                        return RedirectToAction("ViewCustomers", "Home");
                    }
                }
                else
                {
                    return View("AddCustomer");
                }
            }
            return RedirectToAction("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        private void ValidateCustomer(CustomerModel customer)
        {
            if (customer.CustomerFirstname is null)
            {
                ModelState.AddModelError("CustomerFirstname", "First name is required");
            }
            if (customer.CustomerLastname is null)
            {
                ModelState.AddModelError("CustomerLastname", "Last name is required");
            }

            if (customer.ContactNumber is null)
            {
                ModelState.AddModelError("ContactNumber", "Contact number is required");
            }

            if (customer.Email is null)
            {
                ModelState.AddModelError("Email", "Email is required");
            }

            if (customer.HouseNumber is null)
            {
                ModelState.AddModelError("HouseNumber", "House number is required");
            }

            if (customer.Street is null)
            {
                ModelState.AddModelError("Street", "Street is required");
            }

            if (customer.Town is null)
            {
                ModelState.AddModelError("Town", "Town is required");
            }

            if (customer.Postcode is null)
            {
                ModelState.AddModelError("Postcode", "Postcode is required");
            }
        }
    }
}
