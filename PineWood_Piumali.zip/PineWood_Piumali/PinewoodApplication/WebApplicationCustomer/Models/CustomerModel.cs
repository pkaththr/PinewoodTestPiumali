﻿namespace WebApplicationCustomer.Models
{
    public class CustomerModel
    {
        public Guid CustomerId { get; set; }
        public string CustomerFirstname { get; set; } = null!;
        public string CustomerLastname { get; set; } = null!;
        public string HouseNumber { get; set; } = null!;
        public string? Street { get; set; }
        public string? Town { get; set; }
        public string Postcode { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string ContactNumber { get; set; } = null!;
        public virtual ICollection<InvoiceModel> Invoices { get; set; } = new List<InvoiceModel>();

        public string Address
        {
            get
            {
                return string.Concat(HouseNumber, ",", Street, ",", Town, ",", Postcode);
            }
        }

        public bool IsUpdated { get; set; } = false;
    }
}
