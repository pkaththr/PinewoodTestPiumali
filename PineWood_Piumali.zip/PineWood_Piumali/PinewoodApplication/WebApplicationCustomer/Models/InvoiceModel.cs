﻿namespace WebApplicationCustomer.Models
{
    public class InvoiceModel
    {
        public Guid InvoiceId { get; set; }
        public Guid CustomerId { get; set; }
        public string ProductId { get; set; } = null!;
        public string BillingAddress { get; set; } = null!;
        public virtual CustomerModel Customer { get; set; } = null!;
    }
}
