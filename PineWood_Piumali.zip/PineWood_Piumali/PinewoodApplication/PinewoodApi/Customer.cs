﻿using System;
using System.Collections.Generic;

namespace PinewoodApi;

public partial class Customer
{
    public Guid CustomerId { get; set; }

    public string CustomerFirstname { get; set; } = null!;

    public string CustomerLastname { get; set; } = null!;

    public string HouseNumber { get; set; } = null!;

    public string? Street { get; set; }

    public string? Town { get; set; }

    public string Postcode { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string ContactNumber { get; set; } = null!;

    public virtual ICollection<Invoice> Invoices { get; set; } = new List<Invoice>();
}
