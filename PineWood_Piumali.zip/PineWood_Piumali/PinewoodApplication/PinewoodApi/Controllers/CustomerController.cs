﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer.Query.Internal;

namespace PinewoodApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {

        [HttpPost("AddCustomer")]
        public void AddCustomer(Customer customer)
        {
            using (var context = new PinewoodContext())
            {
                Customer cus = new Customer();
                cus.CustomerId = Guid.NewGuid();
                cus.CustomerFirstname = customer.CustomerFirstname;
                cus.CustomerLastname = customer.CustomerLastname;
                cus.HouseNumber = customer.HouseNumber;
                cus.ContactNumber = customer.ContactNumber;
                cus.Email = customer.Email;
                cus.Street = customer.Street;
                cus.Town = customer.Town;
                cus.Postcode = customer.Postcode;
                context.Customers.Add(cus);
                context.SaveChanges();
            }
        }

        [HttpDelete("DeleteCustomer")]
        public ActionResult DeleteCustomer(string customerId)
        {
            if (customerId is null)
            {
                return NotFound();
            }
            using (var context = new PinewoodContext())
            {
                var cus = context.Customers.FirstOrDefault(i => i.CustomerId == Guid.Parse(customerId));
                if (cus is not null)
                {
                    context.Customers.Remove(cus);
                    context.SaveChanges();
                    return Ok();
                }
                return NotFound();
            }
        }

        [HttpPut("UpdateCustomer")]
        public ActionResult UpdateCustomer(Customer customer)
        {
            if (customer is null)
            { 
                return NotFound();
            } 
            else 
            {
                using (var context = new PinewoodContext())
                {
                    try
                    {
                        context.Customers.Update(customer);
                        context.SaveChanges();
                        return Ok();
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        // Handle concurrency conflict
                        throw new Exception("A concurrency conflict occurred.");
                    }                   
                }
            }           
        }

        [HttpGet("GetCustomersByNames")]
        public IEnumerable<Customer?> GetCustomersByNames(string? customerName = null)
        {
            
            using (var context = new PinewoodContext())
            {
                var customers = context.Customers.FromSql($"EXEC GetCustomers @CustomerName = {customerName}").ToList();
                return customers;
            }
        }

        [HttpGet("GetCustomers")]
        public IEnumerable<Customer> GetCustomers()
        {       
            using (var context = new PinewoodContext())
            {
                var customers = context.Customers.ToList();
                return customers;
            }      
        }

        [HttpGet("GetCustomerById")]
        public ActionResult<Customer?> GetCustomerById(string customerId)
        {
            if (customerId is null)
            { 
                return NotFound();
            }
            else
            {
                using (var context = new PinewoodContext())
                {                   
                    var customer = context.Customers.Where(i => i.CustomerId == Guid.Parse(customerId)).FirstOrDefault();
                    return customer;
                }
            }
        }
    }
}
