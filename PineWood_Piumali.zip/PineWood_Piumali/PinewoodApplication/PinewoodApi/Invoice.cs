﻿using System;
using System.Collections.Generic;

namespace PinewoodApi;

public partial class Invoice
{
    public Guid InvoiceId { get; set; }

    public Guid CustomerId { get; set; }

    public string ProductId { get; set; } = null!;

    public string BillingAddress { get; set; } = null!;

    public virtual Customer Customer { get; set; } = null!;
}
