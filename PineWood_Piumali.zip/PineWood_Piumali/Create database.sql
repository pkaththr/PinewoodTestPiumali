-- create data base
CREATE DATABASE Pinewood;

GO

USE Pinewood

GO

CREATE TABLE [dbo].[Customer](
[customer_id]    		 uniqueidentifier  NOT NULL,
[customer_firstname]	 NVARCHAR (50)  NOT NULL,
[customer_lastname]	     NVARCHAR (50)  NOT NULL,
[house_number]       	 NVARCHAR (50)  NOT NULL,
[street]		         NVARCHAR (50)  NULL,
[town]                   NVARCHAR (50)  NULL,
[postcode]	             NVARCHAR (50)  NOT NULL,
[email]                  NVARCHAR (50)  NOT NULL,
[contact_number]         NVARCHAR (50)  NOT NULL,
CONSTRAINT [PK_Customer] PRIMARY KEY ([customer_id] ASC)
)

CREATE TABLE [dbo].[Invoice] (
    [invoice_id]                   uniqueidentifier  NOT NULL,
    [customer_id]                  uniqueidentifier NOT NULL,
    [product_id]                   NVARCHAR (50)  NOT NULL,
    [billing_address]              NVARCHAR (255) NOT NULL,
    CONSTRAINT [PK_invoice] PRIMARY KEY ([invoice_id] ASC),
	CONSTRAINT [FK_customerinvoice] FOREIGN KEY (customer_id) REFERENCES [Customer] ([customer_id]) ON DELETE CASCADE
  )

