--Stored Proceduers
USE Pinewood

GO

CREATE PROCEDURE GetCustomers(@CustomerName VARCHAR(50))
AS
BEGIN

SELECT Customer.customer_id,
Customer.customer_firstname,
Customer.customer_lastname,
Customer.house_number,
Customer.street,
Customer.town,
Customer.postcode,
Customer.email,
Customer.contact_number,
Invoice.invoice_id,
Invoice.product_id,
Invoice.billing_address
FROM Customer
LEFT JOIN Invoice ON Customer.customer_id = Invoice.customer_id
WHERE Customer.customer_firstname LIKE '%' + @CustomerName + '%' OR Customer.customer_lastname LIKE '%' + @CustomerName + '%'

END